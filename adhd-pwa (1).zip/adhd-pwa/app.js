// ===== FocusFlow - ADHD Support PWA =====
// Fully offline, free forever, all data stored locally

// ===== Data Store =====
const DB = {
    get(key, fallback = null) {
        try { return JSON.parse(localStorage.getItem('ff_' + key)) || fallback; }
        catch { return fallback; }
    },
    set(key, val) { localStorage.setItem('ff_' + key, JSON.stringify(val)); },
    push(key, item) {
        const arr = this.get(key, []);
        arr.unshift(item);
        if (arr.length > 500) arr.pop();
        this.set(key, arr);
    }
};

// ===== Initialization =====
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        document.getElementById('splash').classList.add('fade-out');
        document.getElementById('main-app').classList.remove('hidden');
    }, 1500);
    initHome();
    initMeditations();
    initTherapy();
    initSettings();
    updateStreak();
    document.getElementById('chat-input').addEventListener('keypress', e => {
        if (e.key === 'Enter') sendMessage();
    });
    const slider = document.getElementById('cbt-emotion');
    if (slider) slider.addEventListener('input', () => {
        document.getElementById('cbt-emotion-val').textContent = slider.value;
    });
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
});

// ===== Navigation =====
function navigateTo(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-' + page).classList.add('active');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    const navBtn = document.querySelector(`[data-page="${page}"]`);
    if (navBtn) navBtn.classList.add('active');
    const titles = { home: 'FocusFlow', meditation: 'Meditations', chat: 'AI Chat', therapy: 'Behavior Therapy', focus: 'Focus Tools', tools: 'ADHD Tools', settings: 'Settings' };
    document.getElementById('page-title').textContent = titles[page] || 'FocusFlow';
    if (page === 'settings') document.getElementById('settings-btn').style.display = 'none';
    else document.getElementById('settings-btn').style.display = '';
}
document.getElementById('settings-btn').addEventListener('click', () => navigateTo('settings'));

// ===== Home =====
function initHome() {
    const hour = new Date().getHours();
    let greeting = hour < 12 ? 'Good morning!' : hour < 17 ? 'Good afternoon!' : 'Good evening!';
    const name = DB.get('settings', {}).name;
    if (name) greeting = greeting.replace('!', `, ${name}!`);
    document.getElementById('greeting').textContent = greeting;
    const affirmations = [
        "Your brain works differently — that's your superpower.",
        "Progress, not perfection. Every small step counts.",
        "You deserve patience — especially from yourself.",
        "Your worth isn't measured by your productivity.",
        "It's okay to do things differently than others.",
        "You are not lazy. You are wired differently.",
        "Today, focus on one thing. That's enough.",
        "Your challenges don't define you — your resilience does.",
        "Be gentle with yourself. You're doing better than you think.",
        "Every day is a fresh start for your brain."
    ];
    document.getElementById('daily-affirmation').textContent = affirmations[Math.floor(Math.random() * affirmations.length)];
}

function logMood(mood) {
    DB.push('moods', { mood, date: new Date().toISOString() });
    document.querySelectorAll('.mood-btn').forEach(b => b.style.transform = '');
    event.target.style.transform = 'scale(1.3)';
    updateStreak();
}

function updateStreak() {
    const moods = DB.get('moods', []);
    let streak = 0;
    const today = new Date().toDateString();
    const checked = new Set();
    for (const m of moods) {
        const d = new Date(m.date).toDateString();
        if (!checked.has(d)) {
            checked.add(d);
            const diff = Math.floor((new Date(today) - new Date(d)) / 86400000);
            if (diff === streak) streak++;
            else break;
        }
    }
    document.getElementById('streak-count').textContent = `${streak} day${streak !== 1 ? 's' : ''}`;
    document.getElementById('streak-bar').style.setProperty('--streak-width', Math.min(streak * 14.3, 100) + '%');
}

// ===== Meditations =====
const meditations = [
    { id: 1, title: "ADHD Focus Reset", category: "focus", duration: 5, icon: "🎯", description: "Quick reset when you can't concentrate" },
    { id: 2, title: "Calm the Racing Mind", category: "calm", duration: 10, icon: "🌊", description: "Slow down overwhelming thoughts" },
    { id: 3, title: "Body Scan for Restlessness", category: "calm", duration: 8, icon: "🫁", description: "Release physical tension" },
    { id: 4, title: "Sleep Wind-Down", category: "sleep", duration: 15, icon: "🌙", description: "Quiet your mind for restful sleep" },
    { id: 5, title: "Morning Energy Boost", category: "energy", duration: 5, icon: "☀️", description: "Start your day with clarity" },
    { id: 6, title: "Task Transition", category: "focus", duration: 3, icon: "🔄", description: "Smoothly shift between activities" },
    { id: 7, title: "Emotional Regulation", category: "calm", duration: 7, icon: "🌈", description: "Process big emotions gently" },
    { id: 8, title: "Hyperfocus Cool-Down", category: "calm", duration: 5, icon: "❄️", description: "Come back from intense focus" },
    { id: 9, title: "Motivation Spark", category: "energy", duration: 5, icon: "⚡", description: "Reignite your drive" },
    { id: 10, title: "Deep Sleep Journey", category: "sleep", duration: 20, icon: "🌌", description: "Extended guided sleep meditation" },
    { id: 11, title: "Mindful Breathing", category: "focus", duration: 4, icon: "🍃", description: "Anchor yourself in the present" },
    { id: 12, title: "Self-Compassion", category: "calm", duration: 10, icon: "💝", description: "Be kind to your neurodivergent self" }
];

const meditationGuides = {
    1: ["Close your eyes. Take 3 deep breaths.", "Notice where your attention is. Don't judge it.", "Imagine your focus as a flashlight beam.", "Slowly, gather the light into one beam.", "Point it at your breath. In... 2... 3... 4.", "When your mind wanders, gently bring it back.", "No frustration. Just redirect. That IS the practice.", "Your focus is resetting with each breath.", "One more deep breath. You're ready."],
    2: ["Find a comfortable position. You're safe here.", "Notice the thoughts racing through your mind.", "Imagine each thought as a cloud passing by.", "You don't need to grab them. Just watch.", "Breathe in calm... breathe out tension.", "Your mind might speed up - that's okay.", "Return to watching the clouds.", "Slower now. The sky is getting clearer.", "Rest here. Your mind is quieting."],
    3: ["Start at the top of your head.", "Move to your forehead... your jaw... release.", "Feel your shoulders. Let them drop.", "Notice your hands. Open them gently.", "Feel your legs. Let them be heavy.", "Scan for restlessness. Breathe into it.", "Your body is allowed to be still.", "One more full body sweep.", "Rest here in stillness."],
    4: ["Let your eyelids get heavy. The day is done.", "Release every obligation. Tomorrow can wait.", "Breathe in... 2... 3... 4. Hold... 2... 3.", "Out slowly... 2... 3... 4... 5... 6.", "Imagine sinking into a soft cloud.", "Each breath takes you deeper.", "Your racing thoughts are tucked away.", "Nothing to solve right now. Just float.", "Deeper... softer... quieter... rest."],
    5: ["Good morning. Take an energizing breath.", "Stretch your body. Wake up every cell.", "Set one intention for today. Just one.", "Breathe in possibility. Breathe out yesterday.", "You are starting fresh.", "Feel energy building with each breath.", "Just do the next thing.", "One more deep breath. You've got this.", "Open your eyes. Your day begins now."],
    6: ["Pause. You're between tasks.", "Take 3 breaths to clear the old task.", "Let go of what you were doing.", "Now, what's next? Name it.", "Breathe in the new task.", "You're allowed this moment of transition.", "Ready. Set. Begin."],
    7: ["Notice what you're feeling. Name it.", "This emotion is valid.", "Breathe into the feeling.", "Where do you feel it in your body?", "Place your hand there. Send warmth.", "Emotions with ADHD can be intense.", "You won't feel this way forever.", "Breathe through it.", "One more breath. You're doing great."],
    8: ["You've been deeply focused. Time to surface.", "Take a deep breath. Reconnect.", "Wiggle your fingers and toes.", "Look around. Name 3 things you see.", "Stretch. Your body has been waiting.", "Are you hungry? Thirsty?", "The hyperfocus served you.", "Take a slow breath. Welcome back."],
    9: ["Your brain needs dopamine.", "Think of something exciting.", "Feel that spark? Let it grow.", "Connect that energy to your task.", "Find one tiny interesting part.", "You don't need full motivation.", "Just the first step. Make it tiny.", "Breathe in motivation. Begin."],
    10: ["Settle in. Time to let go.", "Your body is heavy and warm.", "Release from your toes upward...", "Your torso softens... arms melt...", "Count backwards... 10... 9... 8...", "Each number deeper... 7... 6... 5...", "Floating now... 4... 3...", "Almost gone... 2...", "Sleep... 1..."],
    11: ["Bring attention to your breath.", "Don't change it. Just notice.", "In through nose... out through mouth.", "Count: In-1, Out-2, In-3, Out-4.", "When you lose count, start at 1.", "No frustration. That IS the practice.", "Keep counting. Keep returning.", "Your mind is a puppy. Guide it back.", "You're building attention right now."],
    12: ["Place your hand on your heart.", "Say: 'Having ADHD is hard sometimes.'", "That's not self-pity. That's truth.", "'Others struggle too. I'm not alone.'", "Breathe compassion toward yourself.", "'May I be patient with myself.'", "'May I accept my brain as it is.'", "'May I be kind to myself.'", "You deserve your own compassion."]
};

function initMeditations() { renderMeditations('all'); }

function renderMeditations(category) {
    const list = document.getElementById('meditation-list');
    const filtered = category === 'all' ? meditations : meditations.filter(m => m.category === category);
    list.innerHTML = filtered.map(m => `
        <div class="med-item" onclick="startMeditation(${m.id})">
            <span class="med-icon">${m.icon}</span>
            <div class="med-info"><h4>${m.title}</h4><p>${m.description}</p></div>
            <span class="med-duration">${m.duration} min</span>
        </div>
    `).join('');
}

function filterMeditations(cat) {
    document.querySelectorAll('.med-cat').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    renderMeditations(cat);
}

let medTimer = null, medSeconds = 0, medPaused = false;

function startMeditation(id) {
    const med = meditations.find(m => m.id === id);
    document.getElementById('meditation-list').classList.add('hidden');
    document.querySelector('.meditation-categories').classList.add('hidden');
    document.getElementById('meditation-player').classList.remove('hidden');
    document.getElementById('player-title').textContent = med.title;
    const guide = meditationGuides[id] || [];
    const guideEl = document.getElementById('meditation-guide');
    guideEl.innerHTML = '';
    medSeconds = 0; medPaused = false;
    const totalSeconds = med.duration * 60;
    let stepIndex = 0;
    const stepInterval = Math.floor(totalSeconds / (guide.length || 1));
    medTimer = setInterval(() => {
        if (medPaused) return;
        medSeconds++;
        const mins = Math.floor(medSeconds / 60), secs = medSeconds % 60;
        document.getElementById('player-timer').textContent = `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
        document.getElementById('breath-instruction').textContent = (medSeconds % 8 < 4) ? 'Breathe in...' : 'Breathe out...';
        if (guide.length && medSeconds % stepInterval === 0 && stepIndex < guide.length) {
            guideEl.innerHTML += `<p style="margin-bottom:8px">${guide[stepIndex]}</p>`;
            guideEl.scrollTop = guideEl.scrollHeight;
            stepIndex++;
        }
        if (medSeconds >= totalSeconds) {
            stopMeditation();
            guideEl.innerHTML += `<p style="font-weight:bold;color:var(--primary)">✨ Session complete. Well done.</p>`;
            DB.push('meditation_log', { id, duration: med.duration, date: new Date().toISOString() });
        }
    }, 1000);
}

function pauseMeditation() {
    medPaused = !medPaused;
    document.getElementById('pause-btn').textContent = medPaused ? '▶️ Resume' : '⏸️ Pause';
}

function stopMeditation() {
    clearInterval(medTimer); medTimer = null;
    document.getElementById('meditation-list').classList.remove('hidden');
    document.querySelector('.meditation-categories').classList.remove('hidden');
    document.getElementById('meditation-player').classList.add('hidden');
}

// ===== AI Chat =====
const aiKnowledge = {
    overwhelmed: [
        "I hear you. Feeling overwhelmed is really common with ADHD, and it's not a personal failing. Here's what might help right now:\n\n🧊 **Ice cube technique**: Hold an ice cube. The sensation brings you to the present.\n\n📝 **Brain dump**: Write everything down. Getting it out of your head reduces pressure.\n\n🎯 **Pick ONE thing**: Not the most important — the easiest. Momentum builds.\n\nWant me to walk you through any of these?",
        "That overwhelmed feeling? It's your working memory maxing out — totally normal for ADHD brains. Try this:\n\n1. Close your eyes for 10 seconds\n2. Take 3 slow breaths\n3. Ask: 'What's the ONE thing that would help right now?'\n\nYou're not behind — you're carrying more mental load than most people.",
        "When everything hits at once, your ADHD brain can freeze. That's not laziness — it's overwhelm paralysis.\n\n⏱️ Set a timer for 5 minutes\n🧹 Do ONE tiny thing\n✅ Done? That's your win.\n\nSmall actions break the freeze."
    ],
    focus: [
        "Let's get you locked in. ADHD brains need the right conditions:\n\n1. **Remove ONE distraction** — phone in another room?\n2. **Set a tiny goal** — 'write the first sentence'\n3. **Add stimulation** — background noise, fidget toy\n4. **Set a timer** — even 10 minutes\n\nYour brain does better with structure + novelty.",
        "Here's the thing about ADHD and focus — you CAN focus, just not on demand. Work WITH your brain:\n\n🎲 **Gamify it**: 'I bet I can't do 3 things in 15 min'\n🎵 **Pair it**: Music, coffee — make it multisensory\n⏰ **Timebox**: 25 min focus, 5 min anything\n\nWhat are you trying to focus on?"
    ],
    procrastination: [
        "Procrastination with ADHD isn't laziness — it's emotional regulation. Your brain avoids tasks that feel:\n\n😰 Overwhelming (too big)\n😑 Boring (not enough dopamine)\n😨 Scary (fear of failure)\n\n**Fixes:**\n- Too big → Break into tiny steps\n- Too boring → Add music, rewards, body double\n- Too scary → Permission to do it imperfectly",
        "Procrastination is a NOW vs NOT-NOW problem. ADHD brains struggle with 'not-now'.\n\n**Make it NOW:**\n⏰ Deadline in 25 minutes\n👥 Tell someone you're starting\n🎯 Make step 1 laughably easy\n🏆 Promise yourself a reward\n\nThe hardest part is starting."
    ],
    strategies: [
        "Top ADHD coping strategies:\n\n**🧠 External Brain**\n- Write everything down immediately\n- One inbox for all tasks\n- Review daily\n\n**⏰ Time Management**\n- Timers for everything\n- Double your time estimates\n- Buffer time for transitions\n\n**🏠 Environment**\n- Make right thing easy, wrong thing hard\n- Visual reminders > mental ones\n- Designated spots for everything\n\n**💪 Self-Care**\n- Sleep affects ADHD massively\n- Exercise = brain medication\n- Protein-rich meals for focus",
        "Strategies by struggle:\n\n**Can't start?** → 2-minute rule. Commit to ONLY 2 minutes.\n**Forgetting?** → Phone reminders, sticky notes, body doubling.\n**Time blind?** → Analog clock, alarms 10 min before.\n**Emotional flooding?** → Name it, rate 1-10, 'will this matter in a week?'\n**Losing focus?** → Fidget tools, background noise, Pomodoro.\n\nExperiment to find YOUR strategies!"
    ],
    general: [
        "ADHD affects everyone differently. What would be most helpful — strategies, emotional support, or understanding why your brain does what it does?",
        "Having ADHD means different wiring — not worse wiring. Some days are harder. That's okay. What would help you most right now?",
        "I'm here for you. I can help with focus, emotional regulation, task management, or just being supportive. What's on your mind?",
        "ADHD comes with unique challenges AND strengths — creativity, hyperfocus, out-of-the-box thinking, empathy. How can I support you?"
    ]
};

function getAIResponse(message) {
    const lower = message.toLowerCase();
    if (lower.match(/overwhelm|too much|can't handle|stressed|anxious|anxiety/)) return randomFrom(aiKnowledge.overwhelmed);
    if (lower.match(/focus|concentrate|distract|attention/)) return randomFrom(aiKnowledge.focus);
    if (lower.match(/procrastinat|can't start|putting off|avoid/)) return randomFrom(aiKnowledge.procrastination);
    if (lower.match(/strateg|tip|cope|help me|advice|what can i do/)) return randomFrom(aiKnowledge.strategies);
    if (lower.match(/sad|depress|hopeless/)) return "I'm sorry you're feeling this way. ADHD and low mood often go together.\n\n💛 You are not broken.\n💛 Your feelings are valid.\n💛 Struggling doesn't mean failing.\n\nIf these feelings persist, please reach out to a professional who understands ADHD.\n\nBasics help: Have you eaten? Had water? Slept?\n\n🆘 Crisis: 988 Suicide & Crisis Lifeline (call/text 988)";
    if (lower.match(/medication|meds|ritalin|adderall|vyvanse/)) return "I can share general info but I'm not a doctor.\n\n**General facts:**\n- Medication works for ~80% of people with ADHD\n- It corrects a neurochemical imbalance\n- Finding the right med/dose takes time\n- Meds work best + behavioral strategies\n\nPlease talk to a psychiatrist who specializes in ADHD. I can help with the behavioral strategies side!";
    if (lower.match(/relationship|partner|friend|family/)) return "ADHD can affect relationships:\n\n- Forgetting important things\n- Emotional impulsivity\n- Hyperfocus then 'losing interest'\n- Feeling misunderstood\n\n**What helps:**\n- Explain ADHD to trusted people\n- External systems (shared calendars)\n- Pause before responding when emotional\n- Find people who appreciate your energy\n\nYou're worthy of connection.";
    if (lower.match(/work|job|career|boss/)) return "ADHD at work strategies:\n\n**Structure:** Written to-do (max 3 priorities), calendar blocking, do-not-disturb\n**Communication:** Take notes, ask for written instructions\n**Accommodation:** Noise-canceling headphones, movement breaks, flexible hours\n\n**ADHD is covered by the ADA** — you can request accommodations.";
    if (lower.match(/sleep|insomnia|tired|exhausted/)) return "ADHD and sleep are closely connected:\n\n**Common issues:**\n- Racing mind at bedtime\n- Revenge bedtime procrastination\n- Difficulty with consistent schedule\n\n**What helps:**\n- Same wake time every day (more important than bedtime)\n- Blue light filter 2 hours before bed\n- Wind-down routine (try our Sleep meditation!)\n- No screens in bed — brain associates bed with stimulation\n- White noise or fan for racing thoughts\n\nSleep is probably the #1 thing that affects ADHD symptoms.";
    return randomFrom(aiKnowledge.general);
}

function randomFrom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    if (!message) return;
    addChatBubble(message, 'user');
    input.value = '';
    document.getElementById('chat-suggestions').style.display = 'none';
    const typing = document.createElement('div');
    typing.className = 'chat-bubble typing';
    typing.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
    document.getElementById('chat-messages').appendChild(typing);
    scrollChat();
    setTimeout(() => {
        typing.remove();
        const response = getAIResponse(message);
        addChatBubble(response, 'ai');
        DB.push('chat_history', { user: message, ai: response, date: new Date().toISOString() });
    }, 800 + Math.random() * 1200);
}

function sendSuggestion(text) {
    document.getElementById('chat-input').value = text;
    sendMessage();
}

function addChatBubble(text, type) {
    const messages = document.getElementById('chat-messages');
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${type}`;
    bubble.innerHTML = `<p>${text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')}</p>`;
    messages.appendChild(bubble);
    scrollChat();
}

function scrollChat() {
    const m = document.getElementById('chat-messages');
    m.scrollTop = m.scrollHeight;
}

// ===== Behavior Therapy =====
function initTherapy() { loadCBTHistory(); loadHabits(); setJournalPrompt(); loadJournalHistory(); }

function switchTherapyTab(tab) {
    document.querySelectorAll('.therapy-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.therapy-section').forEach(s => s.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('therapy-' + tab).classList.add('active');
}

function saveCBTRecord() {
    const record = {
        situation: document.getElementById('cbt-situation').value,
        thought: document.getElementById('cbt-thought').value,
        emotion: document.getElementById('cbt-emotion').value,
        evidenceFor: document.getElementById('cbt-for').value,
        evidenceAgainst: document.getElementById('cbt-against').value,
        balanced: document.getElementById('cbt-balanced').value,
        date: new Date().toISOString()
    };
    if (!record.situation && !record.thought) return;
    DB.push('cbt_records', record);
    ['cbt-situation','cbt-thought','cbt-for','cbt-against','cbt-balanced'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('cbt-emotion').value = 5;
    document.getElementById('cbt-emotion-val').textContent = '5';
    loadCBTHistory();
}

function loadCBTHistory() {
    const records = DB.get('cbt_records', []).slice(0, 10);
    document.getElementById('cbt-history').innerHTML = records.map(r => `
        <div class="cbt-record">
            <h4>${new Date(r.date).toLocaleDateString()} — Emotion: ${r.emotion}/10</h4>
            <p><strong>Situation:</strong> ${r.situation}</p>
            <p><strong>Thought:</strong> ${r.thought}</p>
            <p><strong>Balanced:</strong> ${r.balanced || '(not yet reframed)'}</p>
        </div>
    `).join('');
}

function addHabit() {
    const name = document.getElementById('new-habit').value.trim();
    const freq = document.getElementById('habit-frequency').value;
    if (!name) return;
    const habits = DB.get('habits', []);
    habits.push({ id: Date.now(), name, frequency: freq, streak: 0, history: [] });
    DB.set('habits', habits);
    document.getElementById('new-habit').value = '';
    loadHabits();
}

function loadHabits() {
    const habits = DB.get('habits', []);
    const today = new Date().toDateString();
    document.getElementById('habit-list').innerHTML = habits.map(h => {
        const done = h.history.includes(today);
        return `<div class="habit-item">
            <div class="habit-check ${done?'done':''}" onclick="toggleHabit(${h.id})">${done?'✓':''}</div>
            <span class="habit-name">${h.name}</span>
            <span class="habit-streak">🔥 ${h.streak}</span>
            <button class="habit-delete" onclick="deleteHabit(${h.id})">✕</button>
        </div>`;
    }).join('');
}

function toggleHabit(id) {
    const habits = DB.get('habits', []);
    const habit = habits.find(h => h.id === id);
    if (!habit) return;
    const today = new Date().toDateString();
    if (habit.history.includes(today)) { habit.history = habit.history.filter(d => d !== today); habit.streak = Math.max(0, habit.streak - 1); }
    else { habit.history.push(today); habit.streak++; }
    DB.set('habits', habits); loadHabits();
}

function deleteHabit(id) { DB.set('habits', DB.get('habits', []).filter(h => h.id !== id)); loadHabits(); }

const journalPrompts = [
    "What's one thing your ADHD brain did well today?",
    "What was the hardest part of today?",
    "Write about a moment you felt proud recently.",
    "What does your ideal morning routine look like?",
    "Describe a time ADHD was an advantage.",
    "What would you tell your younger self about ADHD?",
    "What are 3 things you're grateful for?",
    "What habit would you build? What's the smallest step?",
    "How are your energy levels today?",
    "Write a letter of compassion to yourself.",
    "What environment helps you focus best?",
    "What boundary do you need to set?",
    "Describe your relationship with time.",
    "What strategies worked recently?",
    "If your ADHD was a character, what would it look like?"
];

function setJournalPrompt() {
    const day = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
    document.getElementById('journal-prompt').textContent = journalPrompts[day % journalPrompts.length];
}

function saveJournal() {
    const entry = document.getElementById('journal-entry').value.trim();
    if (!entry) return;
    DB.push('journal_entries', { content: entry, prompt: document.getElementById('journal-prompt').textContent, date: new Date().toISOString() });
    document.getElementById('journal-entry').value = '';
    loadJournalHistory();
}

function loadJournalHistory() {
    const entries = DB.get('journal_entries', []).slice(0, 10);
    document.getElementById('journal-history').innerHTML = entries.map(e => `
        <div class="journal-record">
            <div class="date">${new Date(e.date).toLocaleDateString()}</div>
            <div class="content">${e.content}</div>
        </div>
    `).join('');
}

// Exercises
function startExercise(type) {
    const exercises = {
        grounding: { title: "5-4-3-2-1 Grounding", steps: [{t:"5 Things You SEE",d:"Look around. Name 5 things you can see."},{t:"4 Things You TOUCH",d:"Notice 4 textures around you."},{t:"3 Things You HEAR",d:"Listen. What 3 sounds do you notice?"},{t:"2 Things You SMELL",d:"What 2 scents can you detect?"},{t:"1 Thing You TASTE",d:"What can you taste right now?"},{t:"✨ You're Here",d:"You've grounded yourself. The overwhelm is smaller now."}] },
        bodyscan: { title: "Body Scan", steps: [{t:"Get Comfortable",d:"Sit or lie down. Take 3 deep breaths."},{t:"Head & Face",d:"Release tension in forehead, jaw, scalp."},{t:"Neck & Shoulders",d:"Roll shoulders. Let them drop."},{t:"Arms & Hands",d:"Unclench fists. Let fingers soften."},{t:"Chest & Stomach",d:"Feel breath moving. Breathe into tightness."},{t:"Legs & Feet",d:"Release thighs, calves, feet."},{t:"Whole Body",d:"One final breath. You did it."}] },
        reframe: { title: "Cognitive Reframing", steps: [{t:"Identify the Thought",d:"What negative thought is stuck?"},{t:"Find the Distortion",d:"All-or-nothing? Catastrophizing? Mind-reading?"},{t:"Evidence Check",d:"What supports vs contradicts this thought?"},{t:"Alternative View",d:"What would a kind friend say?"},{t:"Action Step",d:"One small thing you can do, or let go?"},{t:"New Thought",d:"Replace with your balanced version."}] },
        values: { title: "Values Clarification", steps: [{t:"Imagine Best Self",d:"Picture your ideal life."},{t:"Core Values",d:"Name your top 3 values."},{t:"Current Alignment",d:"Rate alignment 1-10 for each."},{t:"One Small Step",d:"One action this week for your lowest value?"},{t:"ADHD Strengths",d:"How do your traits SERVE your values?"},{t:"Commitment",d:"Choose one action for today."}] },
        exposure: { title: "Gradual Exposure", steps: [{t:"Name the Avoidance",d:"What have you been avoiding?"},{t:"Rate the Fear",d:"1-10, how anxious?"},{t:"Build a Ladder",d:"What's the TINIEST step? (anxiety 2-3)"},{t:"Prepare",d:"What support do you need?"},{t:"Take the Step",d:"Do the tiny step. You survived."},{t:"Celebrate",d:"You faced something hard. Rest and reward."}] },
        selfcompassion: { title: "Self-Compassion", steps: [{t:"Acknowledge",d:"'This is a moment of struggle.'"},{t:"Common Humanity",d:"'Others feel this too. I'm not alone.'"},{t:"Kind Self-Talk",d:"What would you tell a friend?"},{t:"Release Blame",d:"'ADHD is not my fault. I'm doing my best.'"},{t:"Affirm",d:"'I am worthy of patience — from myself.'"},{t:"Carry Forward",d:"Return to these words when needed."}] }
    };
    const ex = exercises[type];
    const container = document.getElementById('exercise-active');
    container.classList.remove('hidden');
    container.innerHTML = `<h3>${ex.title}</h3>${ex.steps.map((s,i) => `<div class="exercise-step"><h4>Step ${i+1}: ${s.t}</h4><p>${s.d}</p></div>`).join('')}<button onclick="document.getElementById('exercise-active').classList.add('hidden')" class="secondary-btn" style="margin-top:12px">Close</button>`;
    container.scrollIntoView({ behavior: 'smooth' });
}

// ===== Focus Timer =====
let timerInterval = null, timerSeconds = 0, timerTotal = 25*60, isBreak = false;
let pomodoroCount = DB.get('pomodoro_today', { date: new Date().toDateString(), count: 0 });
if (pomodoroCount.date !== new Date().toDateString()) pomodoroCount = { date: new Date().toDateString(), count: 0 };

function setFocusMode(mode) {
    document.querySelectorAll('.focus-mode').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    document.querySelectorAll('.focus-section').forEach(s => s.classList.remove('active'));
    document.getElementById('focus-' + mode).classList.add('active');
}

function startTimer() {
    if (timerInterval) { pauseTimer(); return; }
    const dur = parseInt(document.getElementById('focus-duration').value) || 25;
    if (timerSeconds === 0) timerTotal = dur * 60;
    document.getElementById('timer-start').textContent = '⏸️ Pause';
    document.getElementById('timer-circle').classList.add(isBreak ? 'break' : 'running');
    timerInterval = setInterval(() => {
        timerSeconds++;
        const remaining = timerTotal - timerSeconds;
        if (remaining <= 0) { completeTimer(); return; }
        document.getElementById('timer-text').textContent = `${String(Math.floor(remaining/60)).padStart(2,'0')}:${String(remaining%60).padStart(2,'0')}`;
    }, 1000);
}

function pauseTimer() { clearInterval(timerInterval); timerInterval = null; document.getElementById('timer-start').textContent = '▶️ Resume'; }

function completeTimer() {
    clearInterval(timerInterval); timerInterval = null;
    if (!isBreak) {
        pomodoroCount.count++; DB.set('pomodoro_today', pomodoroCount);
        document.getElementById('pomodoro-count').textContent = `🍅 ${pomodoroCount.count} completed today`;
        isBreak = true; timerSeconds = 0;
        timerTotal = (parseInt(document.getElementById('break-duration').value)||5) * 60;
        document.getElementById('timer-label').textContent = 'Break Time!';
        document.getElementById('timer-circle').className = 'timer-circle break';
        document.getElementById('timer-text').textContent = `${String(Math.floor(timerTotal/60)).padStart(2,'0')}:00`;
        if (Notification.permission === 'granted') new Notification('🍅 Focus complete!', { body: 'Time for a break!' });
    } else { isBreak = false; resetTimer(); if (Notification.permission === 'granted') new Notification('⏰ Break over!', { body: 'Ready for another session?' }); }
    document.getElementById('timer-start').textContent = '▶️ Start';
}

function resetTimer() {
    clearInterval(timerInterval); timerInterval = null; timerSeconds = 0; isBreak = false;
    const dur = parseInt(document.getElementById('focus-duration').value) || 25;
    document.getElementById('timer-text').textContent = `${String(dur).padStart(2,'0')}:00`;
    document.getElementById('timer-label').textContent = 'Focus Time';
    document.getElementById('timer-start').textContent = '▶️ Start';
    document.getElementById('timer-circle').className = 'timer-circle';
}

function setCustomTimer(mins) {
    document.getElementById('focus-duration').value = mins;
    document.querySelectorAll('.focus-mode').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.focus-section').forEach(s => s.classList.remove('active'));
    document.getElementById('focus-pomodoro').classList.add('active');
    resetTimer();
}

// Body Double
let bdInterval = null, bdSeconds = 0;
const encouragements = ["You're doing great.","One step at a time.","I see you working hard.","Progress, not perfection.","Your brain is powerful.","Take a breath.","You're not alone.","Small wins add up.","Be patient with yourself.","You showed up. That counts."];

function startBodyDouble() {
    document.getElementById('bd-start').classList.add('hidden');
    document.getElementById('bd-session').classList.remove('hidden');
    bdSeconds = 0;
    document.getElementById('bd-encouragement').textContent = randomFrom(encouragements);
    bdInterval = setInterval(() => {
        bdSeconds++;
        document.getElementById('bd-timer').textContent = `${String(Math.floor(bdSeconds/60)).padStart(2,'0')}:${String(bdSeconds%60).padStart(2,'0')}`;
        if (bdSeconds % 120 === 0) document.getElementById('bd-encouragement').textContent = randomFrom(encouragements);
    }, 1000);
}

function stopBodyDouble() {
    clearInterval(bdInterval); bdInterval = null;
    document.getElementById('bd-start').classList.remove('hidden');
    document.getElementById('bd-session').classList.add('hidden');
    DB.push('body_double_log', { duration: bdSeconds, date: new Date().toISOString() });
}

// ===== Tools =====
function openTool(tool) {
    const container = document.getElementById('tool-active');
    container.classList.remove('hidden');
    const toolsHTML = {
        taskbreaker: `<h3>✂️ Task Breaker</h3><p>Big task feeling impossible? Break it down.</p><input type="text" id="big-task" placeholder="What's the big task?" style="width:100%;padding:12px;margin:12px 0;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)"><button onclick="breakTask()" class="primary-btn">Break It Down</button><div id="broken-tasks" style="margin-top:16px"></div>`,
        braindump: `<h3>🧠 Brain Dump</h3><p>Get EVERYTHING out of your head.</p><textarea id="brain-dump-text" placeholder="Type everything..." style="width:100%;min-height:200px;padding:16px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)"></textarea><button onclick="saveBrainDump()" class="primary-btn" style="margin-top:12px">Save</button>`,
        routine: `<h3>📋 Routine Builder</h3><select id="routine-type" onchange="loadRoutine()" style="padding:10px;border:1px solid var(--border);border-radius:8px;margin-bottom:12px;background:var(--bg);color:var(--text)"><option value="morning">Morning</option><option value="evening">Evening</option><option value="work">Work Start</option></select><div id="routine-steps"></div><div style="display:flex;gap:8px;margin-top:8px"><input type="text" id="new-routine-step" placeholder="Add step..." style="flex:1;padding:10px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)"><button onclick="addRoutineStep()" class="primary-btn">+</button></div>`,
        rewards: `<h3>🏆 Reward System</h3><p>ADHD brains need rewards!</p><div style="margin:16px 0"><p>🎵 Song • ☕ Drink • 📱 5min scroll • 🍫 Snack • 🎮 Gaming • 🚶 Walk • 📺 Episode • 💬 Call friend</p></div><button onclick="spinReward()" class="primary-btn">🎰 Random Reward</button><p id="reward-result" style="margin-top:12px;font-size:18px;text-align:center;font-weight:bold"></p>`,
        fidget: `<h3>🔮 Digital Fidget</h3><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:16px"><button onclick="this.style.background='hsl('+Math.random()*360+',70%,60%)'" style="height:80px;border-radius:16px;border:none;font-size:24px;cursor:pointer;background:var(--primary)">🎨 Tap</button><button id="counter-btn" onclick="fidgetCount()" style="height:80px;border-radius:16px;border:none;font-size:18px;cursor:pointer;background:var(--accent);color:white">Click: 0</button></div><div style="margin-top:16px;text-align:center"><div id="fidget-spinner" style="font-size:64px;cursor:pointer" onclick="spinFidget()">🌀</div></div>`,
        emergency: `<h3>🆘 Crisis Plan</h3><div style="background:rgba(255,101,132,0.1);padding:16px;border-radius:12px;border-left:4px solid var(--secondary);margin-bottom:16px"><p><strong>In immediate danger? Call 911 or 988</strong></p></div><ol style="padding-left:20px;line-height:2"><li><strong>STOP</strong> — No decisions right now</li><li><strong>BREATHE</strong> — 4 in, 4 hold, 4 out</li><li><strong>GROUND</strong> — Name 5 things you see</li><li><strong>BASICS</strong> — Water? Food? Sleep?</li><li><strong>ONE THING</strong> — Tiniest step forward?</li></ol><p style="margin-top:16px">• This feeling is temporary<br>• You've survived hard days before<br>• ADHD makes emotions 10x bigger<br>• Reaching out is brave, not weak</p>`
    };
    container.innerHTML = toolsHTML[tool] + `<button onclick="document.getElementById('tool-active').classList.add('hidden')" class="secondary-btn" style="margin-top:16px;display:block">Close</button>`;
    container.scrollIntoView({ behavior: 'smooth' });
    if (tool === 'routine') loadRoutine();
}

function breakTask() {
    const task = document.getElementById('big-task').value.trim();
    if (!task) return;
    const steps = [`Open/prepare for "${task}"`, 'Set a 10-minute timer', 'Do the EASIEST part first', 'Take a 2-minute break', 'Do the next smallest piece', 'Repeat until timer rings', 'Continue or save for later?'];
    document.getElementById('broken-tasks').innerHTML = steps.map((s,i) => `<div style="padding:10px;background:var(--bg);border-radius:8px;margin-bottom:8px;display:flex;gap:8px;align-items:center"><input type="checkbox" style="width:18px;height:18px"><span>${i+1}. ${s}</span></div>`).join('');
}

function saveBrainDump() {
    const text = document.getElementById('brain-dump-text').value.trim();
    if (!text) return;
    DB.push('brain_dumps', { content: text, date: new Date().toISOString() });
    document.getElementById('brain-dump-text').value = '';
    alert('Saved! 🧠 Now pick ONE thing from that list.');
}

function addRoutineStep() {
    const step = document.getElementById('new-routine-step').value.trim();
    const type = document.getElementById('routine-type').value;
    if (!step) return;
    const routines = DB.get('routines', {});
    if (!routines[type]) routines[type] = [];
    routines[type].push({ step });
    DB.set('routines', routines);
    document.getElementById('new-routine-step').value = '';
    loadRoutine();
}

function loadRoutine() {
    const type = document.getElementById('routine-type').value;
    const routines = DB.get('routines', {});
    const steps = routines[type] || [];
    document.getElementById('routine-steps').innerHTML = steps.map((s,i) => `<div style="padding:10px;background:var(--bg);border-radius:8px;margin-bottom:8px;display:flex;justify-content:space-between"><span>${i+1}. ${s.step}</span><button onclick="removeRoutineStep(${i})" style="background:none;border:none;cursor:pointer">✕</button></div>`).join('') || '<p style="color:var(--text-light);text-align:center;padding:16px">Add steps above!</p>';
}

function removeRoutineStep(i) {
    const type = document.getElementById('routine-type').value;
    const routines = DB.get('routines', {});
    if (routines[type]) { routines[type].splice(i, 1); DB.set('routines', routines); loadRoutine(); }
}

function spinReward() {
    const rewards = ['🎵 Listen to a favorite song', '☕ Make your favorite drink', '📱 5 min guilt-free scrolling', '🍫 Small treat', '🚶 Quick walk', '🎮 10 min gaming', '📺 One short video', '💬 Text a friend'];
    document.getElementById('reward-result').textContent = randomFrom(rewards);
}

let fidgetCounter = 0;
function fidgetCount() { fidgetCounter++; document.getElementById('counter-btn').textContent = `Click: ${fidgetCounter}`; }
function spinFidget() {
    const el = document.getElementById('fidget-spinner');
    el.style.transition = 'transform 2s ease-out';
    el.style.transform = `rotate(${Math.random()*3600}deg)`;
    setTimeout(() => { el.style.transition = ''; el.style.transform = ''; }, 2500);
}

// ===== Settings =====
function initSettings() {
    const s = DB.get('settings', {});
    if (s.name) document.getElementById('setting-name').value = s.name;
    if (s.dark) { document.documentElement.setAttribute('data-theme', 'dark'); document.getElementById('setting-dark').checked = true; }
    if (s.notifications) document.getElementById('setting-notifications').checked = true;
    document.getElementById('pomodoro-count').textContent = `🍅 ${pomodoroCount.count} completed today`;
}

function saveSetting(key, val) {
    const s = DB.get('settings', {});
    s[key] = val;
    DB.set('settings', s);
    if (key === 'name') initHome();
}

function toggleDarkMode() {
    const dark = document.getElementById('setting-dark').checked;
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    saveSetting('dark', dark);
}

function toggleNotifications() {
    const on = document.getElementById('setting-notifications').checked;
    if (on && Notification.permission !== 'granted') Notification.requestPermission();
    saveSetting('notifications', on);
}

function exportData() {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key.startsWith('ff_')) data[key] = localStorage.getItem(key);
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `focusflow-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
}

function clearAllData() {
    if (!confirm('Delete ALL data? This cannot be undone.')) return;
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
        if (localStorage.key(i).startsWith('ff_')) keys.push(localStorage.key(i));
    }
    keys.forEach(k => localStorage.removeItem(k));
    location.reload();
}
